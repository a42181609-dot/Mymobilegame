import asyncio
import pygame
import sys

# Initialize Pygame
pygame.init()

# Mobile Screen Size (Vertical/Portrait Mode like PUBG Mobile UI)
SCREEN_WIDTH = 360
SCREEN_HEIGHT = 640
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("My First Zero Cost Mobile Game")

# Colors
GREEN = (40, 180, 99)
WHITE = (255, 255, 255)
RED = (231, 76, 60)

# Player Setup (A small shooter circle for mobile)
player_x = SCREEN_WIDTH // 2
player_y = SCREEN_HEIGHT - 100
player_speed = 5

async def main():
    global player_x, player_y
    clock = pygame.time.Clock()

    # Main Game Loop
    while True:
        screen.fill(GREEN)  # Green Ground

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Input Controls (Works for keys now, will add touch controls next)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 20:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < SCREEN_WIDTH - 20:
            player_x += player_speed

        # Draw Player (Futuristic Red Circle)
        pygame.draw.circle(screen, RED, (player_x, player_y), 20)

        # Draw UI Text
        font = pygame.font.SysFont(None, 30)
        text = font.render("EARNINGS: $0", True, WHITE)
        screen.blit(text, (10, 10))

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)  # Required for Pygbag Web running

# Run the game
asyncio.run(main())